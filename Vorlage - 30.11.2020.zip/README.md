# __cra-template

das Repository dient als Basis für etwaige POCs im Frontend und unterstüzt beim initialen Setup der Single Page Application. Zur Aktualisierung ist auf die [Dokumentation](https://create-react-app.dev/docs/updating-to-new-releases/) von `Create React App` zu verweisen. Voraussetzung ist die Verwendung von Visual Studio Code. Mehr dazu [hier](https://dev.azure.com/erzeugung-enbw/EnSIGHT/_wiki/wikis/EnSIGHT.wiki/1971/Frontend-Entwicklung) 
