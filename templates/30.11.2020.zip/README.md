# iibb-cra-template

das Projekt dient als Vorlage für React-Übungen 