import { Container, Divider, Typography } from '@material-ui/core'
import React from 'react'

const App = () => {
    return (
        <Container>
            <Typography variant="h1" align="center">
                Welcome
            </Typography>
            <Divider />
        </Container>
    )
}

export default App
